import { Http } from '@angular/http';
import { Injectable } from '@angular/core';

/*
  Generated class for the MovieProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class MovieProvider {
  private baseURL ='https://api.themoviedb.org/3/';
  constructor(public http: Http) {
    console.log('Hello MovieProvider Provider');
  }

  getLatestMovies(){
    return this.http.get(this.baseURL+'movie/latest?api_key=' + 
    this.getApiKey());
  }

  getPopularMovies(){
    return this.http.get(this.baseURL+'movie/popular?api_key=' + 
    this.getApiKey());
  }

  getApiKey(){
    return '6afae686c417ab1583d8c0ea9e6b6aee';

  }
}
